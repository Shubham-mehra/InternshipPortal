<footer id="footer" class="style2">
        	<div class="footer-top">
            	<div class="container">
                	<div class="row">
                    	<div class="col-sm-6 col-md-3">
                        	<div class="footer-logo"><a href="#"><img src="Azansys_Logo.jpg" style= "height:50px"  alt=""></a></div>
                            <div class="footer-text">
                                <p>The company's expertise is its commitment to offer custom-made web design for every client, from small business websites to giant e-commerce websites. </p>
                                <div class="read-more">
                                    <a href="about-us.php">Read More</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                        	<h5>Our Portals</h5>
                            <ul class="footer-link courses-list">
                                <li><a href="http://www.azansys.com">www.azansys.com</a></li>
                                <!-- <li><a href="#">Banking</a></li>
                                <li><a href="#">Government Recruitment</a></li> -->
                            </ul>
                        </div>
                        <div class="col-sm-6 col-md-3">
							
                        	<h5><i class="fa fa-phone"></i>+1-510-241-5484</h5>
							<h5><i class="fa fa-fax"></i> 0120-2710076</h5>
							<h5><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailTo: ">info@azansys.com</a></h5>
							
							
                            
                        </div>
                        <div class="col-sm-6 col-md-3">
                        	<h5>Contact Us</h5>
                            <div class="contact-view">
                            	<div class="contact-slide">
                                	<p><i class="fa fa-location-arrow"></i>USA Office : New York
65-41 Saunders Street, Suite 4D, Rego Park, New York
Woodbridge, New Jersey USA 00725</p>
                                </div>
								
								<div class="contact-slide">
                                	<p><i class="fa fa-location-arrow"></i>India Branch : Plot no. 16/17 Avas Vikas, Behind HDFC
Bank/LIC Rudrapur, U.S. Nagar
Uttarakhand, India 263152</p>
                                </div>
								
								<div class="contact-slide">
                                	<p><i class="fa fa-location-arrow"></i>Russia Branch : 107023 Moscow, st. Malaya Semenovskaya,
9/3 125476 Moscow, st. Vasiliya Petushkova 8</p>
                                </div>
							
                                
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="copy-right">
                                <p style  = "margin-left:220px;">Copyright © <span class="year">2016</span>Azansys Infotech Pvt. ltd. All Rights Reserved</p>
                            </div>
                        </div>
                        <div class="col-sm-4">	
                            <div class="social-media">
                                <ul>
                                    <li><a href="https://www.facebook.com/calimakwebsolution/"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/MakWebSolution"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://join.skype.com/invite/T3BH2WdiEWvE"><i class="fa fa-skype"></i></a></li>
                                    <li><a href="https://www.youtube.com/channel/UCpvI9-9OJv80V3Eep7_EW0A?view_as=subscriber"><i class="fa fa-youtube"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        