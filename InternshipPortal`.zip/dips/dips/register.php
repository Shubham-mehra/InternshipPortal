<?php

$name = $_POST["uname"];
$email = $_POST["email"];
$pas     = $_POST["pass"];
$repas = $_POST["repass"];

$con = mysqli_connect("localhost","root","","cmwdbb");
$query = "insert into registeration  values ('$name', '$email','$pas','$repas')";
mysqli_query($con, $query); 

if(mysqli_affected_rows($con)>0)
{
	echo "Successfully Signed up";
}

else
{echo "Try again!";}

?>