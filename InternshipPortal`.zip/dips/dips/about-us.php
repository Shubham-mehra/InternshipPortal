<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
    <title>About-us</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/mylogo.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    
<body>
    <div class="wapper">
        
		<!--header1 -->
		<?php
			include 'header1.php';
		?>
		
		<!--header2 -->
		<?php
			include 'header2.php';
		?>
		
		<section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/about-us1.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>About Us</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
        	<div class="container">
            	<ul>
                	<li><a href="index-2.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                </ul>
            </div>
        </section>
        <section class="about-page">
        	<section class="about-ourInfo">
            	<div class="container">
                	<div class="section-title">
                    	<h2>About   AZANSYS INFOTECH PRIVATE LIMITED </h2>
                        <p>Welcome you at www.azansys.com, today we are one of the largest Web Services Company in India & United State with over 1000+ clients across the Globe & Support Network of over 35+ employees.</p>
                    </div>
                    <div class="row">
                    	<div class="col-sm-6">
                        	<h3>Background</h3>
                            <p>Azansys Info Tech Private Limited (India) and Fendikli Inc (New York, USA) together provide wide range of Technical, Consulting and Management Services. 
                            Our focus has always been on latest cutting edge technologies and rapid development solutions, which helped us crafting state of art solutions with best available practices.
                            Our rich experience we have accumulated from working with various technologies and with clients globally, allows us to offer evaluation of IT requirements of your company and provide the best suitable and cost-effective solutions.</p>
                            
                        </div>
                        <div class="col-sm-6">
                        	<h3>Vision and Mission</h3>
                            <p>Impart quality education to meet the needs of profession and society, and achieve excellence in teaching-learning and development.Attract and develop talented and committed human resource, and provide an environment conducive to innovation, creativity, team-spirit and entrepreneurial leadership. </p>
                        </div>
                    </div>
                </div>
            </section>
            <section class="about-students">
            	<div class="container">
                	<div class="section-title">
                    	<h2>Why people love Azansys?</h2>
                        </div>
                    <div class="row">
                    	<div class="col-sm-6 col-md-3">
                        	<div class="box">
                            	<i class="fa fa-trophy"></i>
                                <h4>Courses lead to recruitment</h4>
                        
						</div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                        	<div class="box">
                            	<i class="fa fa-pencil"></i>
                                <h4>Creative learning</h4>

								</div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                        	<div class="box">
                            	<i class="fa fa-book"></i>
                                <h4>Learn with experts</h4>

								</div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                        	<div class="box">
                            	<i class="fa fa-graduation-cap"></i>
                                <h4>On demand</h4>

								</div>
                        </div>
                        
                    </div>
                </div>
            </section>
           <!-- <section class="about-target-audience">
            	<div class="container">
                	<div class="section-title">
                    	<h2>Our target audience</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                    </div>
                    <div class="row">
                    	<div class="col-sm-6">
                        	<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, </p>
                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, </p>
                        </div>
                        <div class="col-sm-6 text-center">
                        	<img src="images/about-img1.png" alt="">
                        </div>
                    </div>
                </div>
            </section>  -->
            
			<section class="about-goals">
            	
				<div class="container">
                	<div class="section-title">
                    	<h2>Goals and objectives of Azansys Infotech Pvt ltd (LLC)</h2>
                        <p style = "font-size:1.5em"><b>We give all that you want.</b></p>
                    </div>
                    <div class="row">
                    	<div class="col-sm-6">
                        	<img src="images/about-img2.png" alt="">
                        </div>
                        <div class="col-sm-6">
                        	<ul class="goals-point">
                            	<li>Learning international work culture an knowledge</li>
                                <li>Career Exploration</li>
                                <li>Gain valuable work experince in your fields</li>
                                <li>Interactual communication and International Culture</li>
                                <li>Opportunity to practice communication and team work skills</li>
                                <li>Meet peers with similar interest	</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>  
          <!--  <section class="about-team">
            	<div class="container">
                	<div class="section-title">
                    	<h2>Meet our Instructors</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                    </div>
                    <div class="row">
                    	<div class="col-sm-4">
                        	<div class="member-box">
                            	<div class="img">
                                	<img src="images/team-member/member-img4.jpg" alt="">
                                    <ul class="sosiyal-mediya">	
                                    	<li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                                <div class="info">
                                	<div class="name">What is Lorem Ipsum?</div>
                                    <div class="designation">Lorem Ipsum is </div>
                                    <p>simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                                    <a href="instructors.html">view More</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                        	<div class="member-box">
                            	<div class="img">
                                	<img src="images/team-member/member-img5.jpg" alt="">
                                    <ul class="sosiyal-mediya">	
                                    	<li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                                <div class="info">
                                	<div class="name">What is Lorem Ipsum?</div>
                                    <div class="designation">Lorem Ipsum is </div>
                                    <p>simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                                    <a href="instructors.html">view More</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                        	<div class="member-box">
                            	<div class="img">
                                	<img src="images/team-member/member-img6.jpg" alt="">
                                    <ul class="sosiyal-mediya">	
                                    	<li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                                <div class="info">
                                	<div class="name">What is Lorem Ipsum?</div>
                                    <div class="designation">Lorem Ipsum is </div>
                                    <p>simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                                    <a href="instructors.html">view More</a>
                                </div>
                            </div>
                        </div>	
                    </div>
                    
                </div>
            </section>
        </section>
        -->
		<!--footer-->
		<?php
			include 'footer.php';
		?>
    
	</div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>
