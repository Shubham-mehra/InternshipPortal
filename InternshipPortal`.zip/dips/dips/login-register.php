<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
    <title>CWM Solutions LogIn</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/Favicon.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    
<body>

<!-- header1 -->
<?php
		include 'header1.php';
	?>    

<!-- header2 -->
<?php
		include 'header2.php';
	?>
	
	
	    <section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/register-bannerImg.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>Login</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
        	<div class="container">
            	<ul>
                	<li><a href="index-2.php">Home</a></li>
                    <li><a href="login-register.php">Login & Register</a></li>
                </ul>
            </div>
        </section>
        <section class="login-view" >
        	<div class="container">
            	<div class="row">
                	<div class="col-sm-12">
                    	<div class="section-title">
                        	<h2>Login</h2>
                            <p>Login to your account below</p>
                        </div>
						<form action = "logi.php" method = "post" >
                        <div class="input-box">
                        	<input type="text" placeholder="User Name" name = "cname">
                        </div>
                        <div class="input-box">
                        	<input type="text" placeholder="Password" name = "sec">
                        </div>
                        <div class="check-slide">
                        	<label class="label_check" for="checkbox-01"><input id="checkbox-01" type="checkbox"> Remember Me</label>
                            <div class="right-link">
                            	<a href="#">Lost Password? </a>
                            </div>
                        </div>
                        <div class="submit-slide" style = "text-align:center">
                        	<input type="submit" value="Login" class="btn" >
                            
                        </div>
                    </div>
                </div>
                <div class="sosiyal-login">
                	<div class="row">
                    	<div class="col-sm-3 col-md-3">
                        	<a href="#" class="facebook"><i class="fa fa-facebook"></i>Facebook</a>
                        </div>
                        <div class="col-sm-3 col-md-3">
                            <a href="#" class="google-pluse"><i class="fa fa-google-plus"></i>Google</a>
                        </div>
                        <div class="col-sm-3 col-md-3">
                            <a href="#" class="twitter"><i class="fa fa-twitter"></i>Twitter</a>
                        </div>
                        <div class="col-sm-3 col-md-3">
                            <a href="#" class="linkedin"><i class="fa fa-linkedin"></i>Linkedin</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
		<!--footer-->
		<?php
			include 'footer.php';
		?>
		
		
    </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>

