<div class="quck-nav style2">
            <div class="contact-no"><a href="contact-us.php">Any query?</a></div>
            <div class="contact-no"><a href="#"><i class="fa fa-phone"></i>+1-510-241-5484, +91-87000-87053, +91-7703915950 </a></div>
            <div class="contact-no"><a href=" "><i class="fa fa-globe"></i>hr@azansys.com</a></div>
            <div class="quck-right">
               <!-- online Help -->
                
				<!-- language section -->
			</div>
        </div>
		
		
		