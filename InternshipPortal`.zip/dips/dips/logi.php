<?php
$name = $_POST["cname"];
$sec = $_POST["sec"];

$con = mysqli_connect("localhost","root","","cmwdb");
$query = "insert into login(username, sec) values ('$name','$sec')";
mysqli_query($con, $query); 

if(mysqli_affected_rows($con)>0)
{
	echo "Go";
}

else
{echo "Try again!";}

?>