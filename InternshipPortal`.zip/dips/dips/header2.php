<header id="header" class="style2">
            <nav id="nav-main">
                <div class="navbar navbar-inverse">
                    <div class="navbar-header">
					
						<div style = "margin-left: 400px;">
						</div>
					
                        <a href="index.php" class="navbar-brand"><img src="Azansys_Logo.jpg" style= "height:50px; width:200px; margin-left: 125px;"  alt=""></a>
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    
                    <div class="navbar-collapse collapse" style = "margin-right:200px;">
                            <ul class="nav navbar-nav" style = " padding-right: 30px;">
                                <li class="active sub-menu" style = " padding-right: 30px;">
                                	<a href="index.php">Home </a>
                                    
                                </li>
                                <li class="mega-menu sub-menu" style = " padding-right: 30px;">
                                	<a href="courses-gride-sideBar.php">Courses</a>
                                    <!-- courses sub menu -->
                                </li>
                                <!-- pages menu -->
								
								
                                <li class="sub-menu" style = " padding-right: 30px;">
                                	<a href="career.php">Career</a>
                                   
                                </li>
                                <li style = " padding-right: 30px;"><a href="about-us.php">About Us</a></li>
                                
                                
								
                                <li style = " padding-right: 30px;"><a href="contact-us.php">Contact Us </a></li>
                            </ul>
                        </div>
                </div>
            </nav>
        </header>