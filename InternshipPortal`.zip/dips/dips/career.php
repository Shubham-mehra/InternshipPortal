<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
   
    <title>Apply Now</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/mylogo.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    
<body>

<!-- header1 -->
<?php
		include 'header1.php';
	?>    

<!-- header2 -->
<?php
		include 'header2.php';
	?>
	
	
	    <section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/register-bannerImg.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>Apply Now</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
        	<div class="container">
            	<ul>
                	<li><a href="index-2.php">Home</a></li>
                    <li><a href="career.php">Career</a></li>
                </ul>
            </div>
        </section>
		
		<section class="breadcrumb">
        	<div class="container">
            	<h4 style = "text-align:center">We are transforming the lives of millions of college students, one meaningful internship at a time.</h4>
				<h4 style  = "text-align:center">Join us in our quest.</h4>
            </div>

        </section>
		
		
		
        <section class="login-view">
        	<div class="container">
            	<div class="row">
                	
					<div class="col-sm-6">
                    	<div class="section-title">
                        	<h2>Events</h2>
                        </div>
						
						<div class="col-sm-12">
							<h5>
								Walkin Interview for Summer Internship - 29th May - 2018 
							</h5>
                        </div>
                        
						
                        <div class="col-sm-12">
							<h5>
								Summer Internship | Complete PHP Learning- Batch Start 4th Jun – 2018
							</h5>
                        </div>
                        
						<div class="col-sm-12">
                        	<h5>
								Walkin Interview for Summer Internship - 16th Jun - 2018 | Complete PHP Learning- Batch Start 4th Jun – 2018 
							</h5>
                        </div>
                        
	                 </div>
                
				<div class="col-sm-6">
	
                    	<div class="section-title">
                        	<h2>REGISTER</h2>
                            <p>Register now - Completely free</p>
                        </div>
						<form action = "reg.php" method = "post">
						<div class="input-box">
                        	<input type="text" placeholder="User Name" name = "cname">
                        </div>
                        <div class="input-box">
                        	<input type="text" placeholder="Email" name  = "email">
                        </div>
                        <div class="input-box">
                        	<input type="password" placeholder="Password" name = "sec">
                        </div>
                        <div class="input-box">
                        	<input type="password" placeholder="Re-Password" name = "resec">
                        </div>
                        <div class="submit-slide">
                        	<input type="submit" value="SIGN UP" class="btn">
                        </div>
                    </div>
				</form>
                </div>
				
				<section class="breadcrumb">
        	<div class="container">
				<div>
				<h3 style  = "text-align:center">Why work with us?</h3>
			</div>
			</div>
			
			
			<div class="row benefits">
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/int.png"><br>
                    Work with an incredible team
                </div>
            </div>
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/locf.png"><br>
                    Lots of Creative Freedom
                </div>
            </div>
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/mad.png"><br>
                    Make a difference
                </div>
            </div>
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/vcf.png"><br>
                    Very competitive packages
                </div>
            </div>
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/cp.png"><br>
                    A career path of your choice
                </div>
            </div>
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/nc.png"><br>
                    No cubicles or dress codes
                </div>
            </div>
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/fwh.png"><br>
                    Flexible work-hours
                </div>
            </div>
            <div class="col-xs-6 col-sm-3 benefit">
                <div class='img-container'>
                    <img src="images/career/fs.png"><br>
                    Fun all the time
                </div>
            </div>
        </div>

			
			
			
			
			
		</section>
				
				
                <div class="sosiyal-login">
                	<div class="row">
					<div  >
						<center>
							<img src="images/career/share.jpg">
						</center>
					</div>
                    

					<div class="col-sm-3 col-md-3">
                        	<a href="#" class="facebook"><i class="fa fa-facebook"></i>Facebook</a>
                        </div>
                        <div class="col-sm-3 col-md-3">
                            <a href="#" class="google-pluse"><i class="fa fa-google-plus"></i>Google</a>
                        </div>
                        <div class="col-sm-3 col-md-3">
                            <a href="#" class="twitter"><i class="fa fa-twitter"></i>Twitter</a>
                        </div>
                        <div class="col-sm-3 col-md-3">
                            <a href="#" class="linkedin"><i class="fa fa-linkedin"></i>Linkedin</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
			
        
		<!--footer-->
		<?php
			include 'footer.php';
		?>
		
		
    </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>

