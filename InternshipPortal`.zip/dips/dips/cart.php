<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
    <title>Academy</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/Favicon.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    
<body>
    <div class="wapper">
        
		<!--header1-->
		<?php
			include 'header1.php';
		?>
		
		<!--header2-->
		<?php
			include 'header2.php';
		?>
		
	  
	  <section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/cart.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>Cart</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb ">
        	<div class="container">
            	<ul>
                	<li><a href="#">Home</a></li>
                    <li><a href="#">Cart</a></li>
                </ul>
            </div>
        </section>
        <section class="cart-page">
        	<div class="container">
            	<div class="table-view">
                    <div class="cart-table">
                        <table>
                            <tr>
                                <th>PRODUCT</th>
                                <th>PRICE</th>
                                <th>QUANTITY</th>
                                <th>TOTAL</th>
                                <th>&nbsp;</th>
                            </tr>
                            <tr>
                                <td>
                                	<div class="product-details">
                                        <div class="img"><img src="images/courses/cart-img1.jpg" alt=""></div>
                                        <div class="name">Industry's Standard</div>
                                    </div>
                                </td>
                                <td><span class="small-text">PRICE</span>$400</td>
                                <td>
                                	<span class="small-text">QUANTITY</span>
                                    <div class="quantity-box">
                                        <i class="fa fa-minus"></i>
                                        <input type="text" value="1">
                                        <i class="fa fa-plus"></i>
                                    </div>
                                </td>
                                <td><span class="small-text">TOTAL</span>$440</td>
                                <td><span class="small-text">Remove Item</span><a href="#" class="close-icon"><span>Delete</span><i class="fa fa-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td>
                                	<div class="product-details">
                                        <div class="img"><img src="images/courses/cart-img1.jpg" alt=""></div>
                                        <div class="name">Industry's Standard</div>
                                    </div>
                                </td>
                                <td><span class="small-text">PRICE</span>$400</td>
                                <td>
                                	<span class="small-text">QUANTITY</span>
                                    <div class="quantity-box">
                                        <i class="fa fa-minus"></i>
                                        <input type="text" value="1">
                                        <i class="fa fa-plus"></i>
                                    </div>
                                </td>
                                <td><span class="small-text">TOTAL</span>$440</td>
                                <td><span class="small-text">Remove Item</span><a href="#" class="close-icon"><span>Delete</span><i class="fa fa-trash"></i></a></td>
                            </tr>
                        </table>
                    </div>
                    <div class="cart-total">
                        <table>
                            <tr>
                                <td>Total:</td>
                                <td>$6,899.00</td>
                            </tr>
                            <tr>
                                <td>Delivery Charges:</td>
                                <td>$50.00</td>
                            </tr>
                            <tr class="total">
                                <td>Total Amount [?]”</td>
                                <td>$6,999.00</td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="cart-row">
                	<div class="coupon-code">
                    	<input type="text" placeholder="Coupon code">
                        <input type="submit" value="APPLY" class="btn">
                    </div>
                    <div class="check-outBtn">
                    	<a href="check-out.html" class="btn">Proceed to Checkout</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="our-course">
        	<div class="container">
            	<div class="section-title">
                	<h2>YOU MAY BE INTERESTED IN</h2>
                </div>
            	<div class="row">
                	<div class="col-md-4 col-sm-6">
                    	<div class="course-box">
                        	<div class="img">
                            	<img src="images/courses/courses-img1.jpg" alt="">
                                <div class="course-info">
                                	<div class="date"><i class="fa fa-calendar"></i>16-09-2016</div>
                                    <div class="date"><i class="fa fa-clock-o"></i>2 Days </div>
                                    <div class="favorite"><a href="#"><i class="fa fa-heart-o"></i></a></div>
                                </div>
                                <div class="price">$100</div>
                           	</div>
                            <div class="course-name">Management<span><em>By </em>Sarah Johnson</span></div>
                            <div class="comment-row">
                            	<div class="rating">
                                    <div class="fill" style="width:45%"></div>
                                </div>
                                <div class="box"><i class="fa fa-users"></i>35 Student</div>
                                <div class="enroll-btn">	
                                	<a href="#" class="btn">Enroll</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                    	<div class="course-box">
                        	<div class="img">
                            	<img src="images/courses/courses-img2.jpg" alt="">
                                <div class="course-info">
                                	<div class="date"><i class="fa fa-calendar"></i>17-09-2016</div>
                                    <div class="date"><i class="fa fa-clock-o"></i>1 Days </div>
                                    <div class="favorite"><a href="#"><i class="fa fa-heart"></i></a></div>
                                </div>
                                <div class="price free">free</div>
                           	</div>
                            <div class="course-name">Banking<span><em>By </em>Michael Windzor</span></div>
                            <div class="comment-row">
                            	<div class="rating">
                                    <div class="fill" style="width:45%"></div>
                                </div>
                                <div class="box"><i class="fa fa-users"></i>30 Student</div>
                                <div class="enroll-btn">	
                                	<a href="#" class="btn">Enroll</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                    	<div class="course-box">
                        	<div class="img">
                            	<img src="images/courses/courses-img3.jpg" alt="">
                                <div class="course-info">
                                	<div class="date"><i class="fa fa-calendar"></i>17-09-2016</div>
                                    <div class="date"><i class="fa fa-clock-o"></i>1 Days </div>
                                    <div class="favorite"><a href="#"><i class="fa fa-heart-o"></i></a></div>
                                </div>
                                <div class="price">$276</div>
                           	</div>
                            <div class="course-name">Government Recruitment<span><em>By </em>Peter Parker</span></div>
                            <div class="comment-row">
                            	<div class="rating">
                                    <div class="fill" style="width:45%"></div>
                                </div>
                                <div class="box"><i class="fa fa-users"></i>30 Student</div>
                                <div class="enroll-btn">	
                                	<a href="#" class="btn">Enroll</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
		<!--footer-->
		<?php
			include 'footer.php';
		?>
		
		
    </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>

