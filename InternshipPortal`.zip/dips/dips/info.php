<?php
$selectoption    =  $_POST["degree"];
$collegename  =  $_POST["cname"];
$firstname        =  $_POST["fname"];
$email              =  $_POST["email"];
$number          =  $_POST["number"];

$con = mysqli_connect("localhost","root","","cmwdb");
$query = "insert into info(Degree, Collegename, Firstname, Email, Number) values ('$selectoption','$collegename','$firstname','$email', $number)";
mysqli_query($con, $query); 

if(mysqli_affected_rows($con)>0)
{
	echo "<script>alert('Successfully Done!');
		window.location.href='index.php';
		</script>";
}

else
{
	echo "<script>alert('Failed!');
		window.location.href='index.php';
		</script>";
}

?>