-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2018 at 10:04 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cmwdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `ID` int(11) NOT NULL,
  `Degree` varchar(255) DEFAULT NULL,
  `CollegeName` varchar(255) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Number` bigint(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`ID`, `Degree`, `CollegeName`, `FirstName`, `Email`, `Number`) VALUES
(1, 'Degree', 'KEC DWARAHAT', 'Shubham', 'ranashubham98@gmail.com', 2147483647),
(2, 'Degree', 'KEC DWARAHAT', 'PRAVEEN', 'ranashubham98@gmail.com', 2147483647),
(3, 'Degree', 'KEC DWARAHAT', 'Shubham', 'ranashubham98@gmail.com', 2147483647),
(4, 'Degree', 'KEC DWARAHAT', 'PRAVEEN', 'ranashubham98@gmail.com', 9720194605),
(5, 'Degree', 'KEC DWARAHAT', 'PRAVEEN', 'ranashubham98@gmail.com', 9720194605),
(7, 'Degree', 'KEC DWARAHAT', 'Shubham', 'ranashubham98@gmail.com', 9720194605),
(8, 'bca', 'KEC DWARAHAT', 'Shubham', 'ranashubham98@gmail.com', 9720194605),
(9, 'be', 'KEC DWARAHAT', 'Shubham', 'ranashubham98@gmail.com', 9720194605),
(10, 'mca', 'KEC DWARAHAT', 'Shubham', 'ranashubham98@gmail.com', 9720194605),
(11, 'bca', 'KEC DWARAHAT', 'Shubham Rana', 'ranashubham98@gmail.com', 9720194605),
(12, 'bca', 'KEC DWARAHAT', 'Shubham Rana', 'ranashubham98@gmail.com', 9720194605),
(13, 'mca', 'KEC DWARAHAT', 'Shubham Rana', 'ranashubham98@gmail.com', 9720194605),
(14, 'bca', 'KEC DWARAHAT', 'Shubham', 'ranashubham98@gmail.com', 9720194605);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `ID` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `message` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`ID`, `name`, `email`, `subject`, `message`) VALUES
(1, 'Shubham Rana', 'ranashubham98@gmail.com', 'check', ''),
(2, 'Shubham Rana', 'ranashubham98@gmail.com', 'check', 'Is it working?'),
(3, 'Shubham Rana', 'ranashubham98@gmail.com', 'Re', 'It is working.'),
(4, 'Shubham Rana', 'ranashubham98@gmail.com', 'again', '123'),
(5, 'Shubham Rana', 'ranashubham98@gmail.com', 'again1', '1234'),
(6, 'Shubham Rana', 'ranashubham98@gmail.com', 'again1', '1234'),
(7, 'Shubham Rana', 'ranashubham98@gmail.com', 'pta ni kya ho rha h', 'kchh to karo...'),
(8, 'Shubham Rana', 'ranashubham98@gmail.com', 'Is baaar dekhte h..', 'Hota h ya ni...'),
(9, 'Shubham Rana', 'ranashubham98@gmail.com', 'pta ni kya ho rha h', 'qwerty'),
(10, 'Shubham Rana', 'ranashubham98@gmail.com', 'pta ni kya ho rha h', 'GHKKK');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `ID` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `sec` varchar(20) DEFAULT NULL,
  `resec` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`ID`, `username`, `email`, `sec`, `resec`) VALUES
(1, 'ranashubham', 'ranashubham98@gmail.com', 'qwerty', 'qwerty'),
(2, 'shubham rana', 'ranashubham98@gmail.com', 'qwerty@123', 'qwerty@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
