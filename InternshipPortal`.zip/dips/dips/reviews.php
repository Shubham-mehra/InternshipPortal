<section class="student-reviews">
        	<div class="container">
            	<div class="section-title2">
                	<!-- <h2>Testimonials</h2> -->
                </div>
                <div class="reviews-slider">
                	<div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/shubh.png" alt=""></div>
                            <p>I am immensely thankful to CaliMak Web Solutions pvt ltd (LLC)  for providing the Complete PHP internship program which helped me to apply my knowledge and improve my skills. The Developer Team is dedicated to student success and innovation, making Calimak  an exciting place, flexible and professional environment for learning .	”</p>
                            <div class="name">- S K Rana</div>
                        </div>
                	</div>
                    <div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/ayushi.jpg" alt=""></div>
                            <p> I've been working at calimak web solutions (LLC) as an intern. A relatively good and encouraging atmosphere. It's a good place to learn and great team support.   </p>
                            <div class="name">- Ayushi Mishra</div>
                        </div>
                	</div>
                    
                    <div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/gun.jpg" alt=""></div>
                            <p> At Calimak  I got a chance to be a part of Corporate work tradation. Here everyone is considered equally and each suggestion and ideas are equally valuable. Easily adaptable work environment.</p>
                            <div class="name">- Gunjan Chaudhary</div>
                        </div>
                	</div>
                    <div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/mannu_pic.jpg" alt=""></div>
                            <p><b>Excellent working and Exploring Environment</b> At Calimak I get good Co-working environment and often get oppertunities to explore and enhance skill.All the  colleagues are extremly cooperative.And of course Mayank Sir is an fabulous team mentor.  As an Intern at Calimak ,I would Simply say Wow!! </p>
                            <div class="name">- Mannu Kumar</div>
                        </div>
                	</div>
                </div>
            </div>
        </section> 