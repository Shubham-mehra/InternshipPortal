<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
	
	
    <title>Azansys</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/mylogo.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/loader.css" rel="stylesheet"><!--  loader css -->
    <link href="css/jquery.selectbox.css" rel="stylesheet"><!-- select box -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

	<script type = "text/javascript">
		function show2(id)
		{
			if(id == "e1")
			{
				document.getElementById("exp").innerHTML = " We are going to organize a Walk-in Interview for Summer Internship in different IT fields(HTML,JavaScript,CSS,PHP,SQL,SEO,AJAX,Bootstrap,JQuerry... and many more)";
				document.getElementById("title").innerHTML = " Walk-in Interview";
				document.getElementById("date").innerHTML = " 29 may, 2018";		
			document.getElementById('def').style.backgroundImage = "url(images/event/img6.jpg)";
			}		
			
			if(id == "e2")
			{
				document.getElementById("exp").innerHTML = " Summer Internship | Complete PHP Learning- Batch Start ";
				document.getElementById("title").innerHTML = " Complete PHP Learning- Batch Start";
				document.getElementById("date").innerHTML = " 4th Jun, 2018";	
				document.getElementById('def').style.backgroundImage = "url(images/event/img7.jpg)";
			}	
			
			if(id == "e3")
			{
				document.getElementById("exp").innerHTML = "  We are going to organize a Walk-in Interview for PHP developer.";
				document.getElementById("title").innerHTML = "Walk-in Job Interview";
				document.getElementById("date").innerHTML = " 15th Jun, 2018";	
				document.getElementById('def').style.backgroundImage = "url(images/event/img2.jpg)";
			}	
		}
		
		function check()
		{

			var cname = document.getElementById("cname").value;
			var fname = document.getElementById("fname").value;
			var email = document.getElementById("email").value;
			var number = document.getElementById("number").value;
			
			var p = /[0-9]/;
			var p1 = /[-!$%^&*()_+/\|~=`{}[:;<>?,.@#\]]/g;
			var p2 = /[aA-zZ]/;
			
			if(cname.match(p) 	|| (cname.match(p1)) )
			{
				var str = cname.substr(0, cname.length-1);
				alert(" Don't use numbers and special characters!");
				document.getElementById("cname").value = str;
			}
			
			else if(fname.match(p) 	|| (fname.match(p1)) )
			{
				var str = fname.substr(0, fname.length-1);
				alert(" Don't use numbers and special characters!");
				document.getElementById("fname").value = str;
			}
			
			else if( (email.charAt(0).match(p) ) || (email.charAt(0).match(p1) ))
			{
				var str = email.substr(0, email.length-1);
				alert("Invalid Email");
				document.getElementById("email").value = str;
			}
				
				else if( (number.match(p1) ) ||(number.match(p2) ))
			{
				var str = number.substr(0, number.length-1);
				alert("Invalid Number");
				document.getElementById("number").value = str;
			}
		}
	</script>
	
	
	
	
	
</head>
    
<body>
    <div class="wapper">
		
		<!--header1-->
		<?php
			include 'header1.php';
		?>
    	
        <!-- header2 -->
		<?php
			include 'header2.php';
		?>
		
        <section class="banner style2">
        	<div class="left-slider">
            	<div class="item">
                	<img src="images/banner/slide1.jpeg" alt="">
                    <div class="slide-info">
                    	<h2>Education Needs  Complete Solution</h2>
                    </div>
                </div>
                <div class="item">
                	<img src="images/banner/slide3.jpeg" alt="">
                    <div class="slide-info">
                    	<h2>Learning international work culture and knowledge</h2>
                        
                    </div>
                </div>
                <div class="item">
                	<img src="images/banner/banner3.jpg" alt="">
                    <div class="slide-info">
                    	<h2>You may be recruit for a full time</h2>
                    </div>
                </div>
            </div>
            
			<div class="info-form">
            	<h2>Request More Information</h2>
                <div class="row">
				<form action = "info.php" method = "post">
                	<div class="col-sm-12">
                    	<div class="select-box">
                        	<select class="degree-select" name = "degree">
                            	<option > Select-Degree</option>
                                <option value = "bca">B.C.A</option>
                                <option value = "mca">M.C.A</option>
                                <option value = "be">B.E</option>
                            </select>
                        </div>
                    </div>

					<div class="col-sm-12">
                        <div class="input-box">
                            <input type="text" placeholder="College Name" name = "cname" required = "" id = "cname" oninput = "check()">
                        </div>
                    </div>
                    
					<div class="col-sm-12">
                        <div class="input-box">
                            <input type="text" placeholder= "Name" name = "fname" required = "" id = "fname" oninput = "check()">
                        </div>
                    </div>
                  
                	<div class="col-sm-12">
                        <div class="input-box">
                            <input type="text" placeholder="Email" name = "email" required = "" id = "email"  oninput = "check()">
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="input-box">
                            <input type="text" placeholder="Phone Number" name = "number" required = "" id  = "number" oninput = "check()">
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                    	<div class="submit-box">
                        	<input type="submit" value="Enroll Now" onclick = "chek()">
                        </div>
                    </div>
                 </form>
				</div>
            </div>
        </section>
        <section class="safe-environment">
        	<div class="container">
            	<div class="row">
                	<div class="col-sm-12 col-md-4">
                    	<div class="section-title2">
                        	<h2>Develop Your Professional Skills</h2>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                    	<p>Azansys Infotech  offers the Internship Program in Different education Program (Computer Science & Information Technology) for students and freshers.</p>
                        <p>The Internship program runs all through the year in different batches in Our locations.</p>
                    </div>
                     <div class="col-md-4 col-sm-6">
                    	<p>The Summer Internship program is different in the sense that it does not just train students to execute projects but it trains them in all aspects of project management such as project planning, requirements analysis, specification generation, design iteration management, teamwork & ethics, behavior management, team building, group etiquette, and communication skills. </p>
                        
                    </div>
                </div>
            </div>
        </section>
        <section class="our-advantages">
        	<div class="container">
            	<div class="row">
                	<div class="col-sm-4">
                    	<div class="advantages-box">
                        	<div class="img"><img src="images/learn-icon.png" alt=""></div>
                            <h3>Your Education. Your Way.</h3>
                            <p>The key in picking a path is to know yourself, your talents, and your interests. Common advice used to be “Do what you love and the money will follow.” Perhaps better advice would be to recognize that whatever you do, it’s going to take work. By finding an industry that matches your skill set, you can learn to love the work. </p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                    	<div class="advantages-box">
                        	<div class="img"><img src="images/save-timeIcon.png" alt=""></div>
                            <h3>A Great Place to Start</h3>
                            <p>We are committed to delivering values and our mission is to be "Best Service Providing Company " in USA, New Zealand, India, Nepal, Dubai, Singapur . Our IT team backed with indigenously developed system. </p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                    	<div class="advantages-box">
                        	<div class="img"><img src="images/online-learningIcon.png" alt=""></div>
                            <h3>Your Future, Our Focus</h3>
                            <p>We are a learning organization who encourages development of knowledge, skills and attitudes to enable our people to perform to their full potential. We have developed a corporate-wide training programme to bring learning to the work place through the use of in-house, qualified trainers. Individual training needs are identified, training objectives are set, and the appropriate modules are implemented.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="our-studies">
        	<div class="container">
            	<div class="section-title2">
                	<h2>Our Studies</h2>
                </div>
                <div class="row">
                	<div class="col-sm-6 col-md-4">
                    	<div class="studies-box color1">
                        	<div class="name"><a href="#">Custom Web Development</a></div>
                            <p>Design Smart Web offers a complete web design solution to meet the demands of any size project</p>
							
							<br><br><p><a href = "http://www.calimak.com">visit our official website</a></p>
						</div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                    	<div class="studies-box color2">
                        	<div class="name"><a href="#">Digital Marketing</a></div>
                            <p>Get a smart and eye catchy identity to grab mammoth audience’s attention, only possible with good & smart domain name</p>
							<br><p><a href = "http://www.calimak.com">visit our official website</a></p>
						</div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                    	<div class="studies-box color3">
                        	<div class="name"><a href="#">E-COMMERCE Portals</a></div>
                            <p>Make your online shopping website livelier and user friendly with our reasonable & customized ecommerce solutions.</p>
							<br><p><a href = "http://www.calimak.com">visit our official website</a></p>
						</div>
                    </div>
                   
                </div>
            </div>
        </section>
        <section class="sign-upBox" style="background-image:url(images/parallax/sign-upBg.jpg);">
        	<img src="images/parallax/sign-upBg.jpg" alt="">
            <div class="sign-upText">
            	<h3><span>Effective guidance of expert developers helps you to increase your professional skills & knowledge.</span>Get Started Today!</h3>
                <p>Effective SEO helps increase traffic by improving overall visibility in search engines, from non-paid search listings.</p>
                <div class="sign-btn">
                	<a href="career.php">Enroll Now</a>
                </div>
            </div>
        </section>
        <section class="news-section">
        	<div class="container">
            	<div class="section-title2">
                	<h2>Latest News and Events </h2>
                </div>
                <div class="row">
                	<div class="col-md-6 col-sm-12">
                    	<div class="news-box img" style="background-image:url(images/news/news-img1.jpg);" id = "def">	
						 <div   >
						 
                        	<div class="category">News </div>
                            <div class="name" > 
							<p id = "title">  </p>   
								<p id = "date" lass="date">  </p>  
							</div>
                            
                            <p id = "exp">             </p>
                            
						</div>	
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-2" >
                    	<div class="news-box" style="height:286px;">
								<div class="category">Event</div>
									<div class="name">
											<p style="cursor:pointer; color:#4CAF50; font-weight: bold; font-size: 20px" id = "e1" onclick = "show2(this.id)" class="name">
												Walk-in Interview</p></div>
										<div class="date">29th May, 2018</div>
										<p>We are going to organize a Walkin Interview for Summer Internship in different IT fields.</p>
								</div>
						</div>		
                    <div class="col-sm-6 col-md-2">
                    	<div class="news-box" style="height:286px;">
                        	<div class="category">Event</div>
                            <div class="name"><p style="cursor:pointer; color:#4CAF50; font-weight: bold; font-size: 20px"  id = "e2" onclick = "show2(this.id)" class="name">
							Free Internship on Php Batch Start </p></div>
                            <div class="date">4th Jun, 2018</div>
                            <p>We are starting a batch for php internship. </p>
                            
                        </div>
                    </div>
					<div class="col-sm-6 col-md-2">
                    	<div class="news-box" style="height:280px;">
                        	<div class="category">Event</div>
                            <div class="name"><p style="cursor:pointer; color:#4CAF50; font-weight: bold; font-size: 20px"  id = "e3" onclick = "show2(this.id)" class="name">
							Walk-in Job Interview</p></div>
                            <div class="date">15th Jun, 2018</div>
                            <p>Walk-in job Interview for Php Developer. </p>
                            
                        </div>
                    </div>
					
					
                    
					
				</div>
            </div>
        </section>
        <section class="student-reviews">
        	<div class="container">
            	<div class="section-title2">
                	<h2>Testimonials</h2>
                </div>
                <div class="reviews-slider">
                	<!-- <div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/shubh.png" alt=""></div>
                            <p>I am immensely thankful to Azansys Infotech pvt ltd (LLC)  for providing the Complete PHP internship program which helped me to apply my knowledge and improve my skills. The Developer Team is dedicated to student success and innovation, making Calimak  an exciting place, flexible and professional environment for learning .	”</p>
                            <div class="name">- S K Rana</div>
                        </div>
                	</div> -->
                    <div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/ayushi.jpg" alt=""></div>
                            <p> I've been working at Azansys Infotech pvt ltd as an intern. A relatively good and encouraging atmosphere. It's a good place to learn and great team support.   </p>
                            <div class="name">- Ayushi Mishra</div>
                        </div>
                	</div>
                    
                    <div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/gun.jpg" alt=""></div>
                            <p> At Calimak  I got a chance to be a part of Corporate work tradation. Here everyone is considered equally and each suggestion and ideas are equally valuable. Easily adaptable work environment.</p>
                            <div class="name">- Gunjan Chaudhary</div>
                        </div>
                	</div>
                    <div class="item">
                    	<div class="student-box">
                            <div class="img"><img src="images/user-img/mannu_pic.jpg" alt=""></div>
                            <p><b>Excellent working and Exploring Environment</b> At Azansys I get good Co-working environment and often get oppertunities to explore and enhance skill.All the  colleagues are extremly cooperative.And of course Mayank Sir is an fabulous team mentor.  As an Intern at Azansys ,I would Simply say Wow!! </p>
                            <div class="name">- Mannu Kumar</div>
                        </div>
                	</div>
                </div>
            </div>
        </section> 
        
        
		<!--footer-->
		<?php
			include 'footer.php';
		?>
		<div class="top-arrow" id="goTop">
        	<div class="arrow"><i class="fa fa-angle-up"></i></div>
        </div>
        <div class="search-blcok">
        	<div class="close-icon">
            	<i class="fa fa-close"></i>
            </div>
        	<div class="input-box">
        		<input type="text" placeholder="Enter Keyword">
                <div class="note">Input your search keywords and press Enter.</div>
            </div>
        </div>
    </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type="text/javascript" src="js/jquery.selectbox-0.2.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>
</html>

