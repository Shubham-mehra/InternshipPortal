<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
	
    <title>Bootstrap</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/mylogo.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet"> 
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    
<body>
    <div class="wapper">
        <!-- header1 -->
<?php
		include 'header1.php';
	?>  
		
		<?php
		include 'header2.php';
	?>
		
		<section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/courses-banner.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>SQL</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
        	<div class="container">
            	<ul>
                	<li><a href="index.php">Home</a></li>
                    <li><a href="courses-gride-sideBar.php">All courses</a></li>
                    <li><a href="course-details-sql.php">SQL</a></li>
                </ul>
            </div>
        </section>
        <div class="course-details">
        	<div class="container">
            	<h2>SQL</h2>
	            <div class="course-details-main">
                    <div class="course-img">
                        <img src="images/courses/courses-img8.jpg" alt="">
                    </div>
                    <div class="course-info">
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-file"></i></div>
                            <!-- <p>17 Lessons</p> -->
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-exclamation"></i></div>
                            <!-- <p>7 Quizzes</p> -->
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-file-text-o"></i></div>
                            
							<!-- <p>13 Documents</p> -->
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-video-camera"></i></div>
                          <!--  <p>9 vedio</p> -->
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-mortar-board"></i></div>
                            <!-- <p>1719 Students</p> -->
                        </div>
                    </div>
					
                    <div class="row">
                 <!--   	<div class="col-sm-6">
                        	<div class="course-instructorInfo">
                            	<div class="info-slide"><i class="fa fa-user-secret"></i>Rebecca Smith</div>
                                <div class="info-slide"><i class="fa fa-calendar"></i>16-09-2016 - 15-08-2018 </div>
                            </div>
                        </div>  -->
                        <div class="col-sm-6">
                        	<div class="btn-row">
                            	<div class="price"><span>Price: </span>$45</div>
                                
                                <a href="career.php" class="btn"><i class="fa fa-cart-plus"></i>Enroll Now</a>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="info">
                	<h4>Course Overview</h4>
                    <p> Learn to write SQL queries to create, manage, and store information in the database.  </p>
                </div>
				
				<!--
                <div class="instructors">
                	<h4>Meet The Instructors</h4>
                    <div class="row">
                    	<div class="col-sm-4">
                        	<div class="instructors-box">
                            	<div class="img"><img src="images/user-img/img6.jpg" alt=""></div>
                                <div class="name">variations passages</div>
                                <div class="designation">reasonable</div>
                                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                                <div class="link"><a href="instructor-profile.html">More Info</a></div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                        	<div class="instructors-box">
                            	<div class="img"><img src="images/user-img/img7.jpg" alt=""></div>
                                <div class="name">variations passages</div>
                                <div class="designation">reasonable</div>
                                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                                <div class="link"><a href="instructor-profile.html">More Info</a></div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                        	<div class="instructors-box">
                            	<div class="img"><img src="images/user-img/img8.jpg" alt=""></div>
                                <div class="name">variations passages</div>
                                <div class="designation">reasonable</div>
                                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                                <div class="link"><a href="instructor-profile.html">More Info</a></div>
                            </div>
                        </div>
                        
                    </div>
                </div>  -->
                <div class="syllabus">
                	<h4>Syllabus</h4>
                    <div class="syllabus-box">
                        <div class="syllabus-view first">
                        	<div class="main-point active">SQL</div>
                            <div class="point-list">
                            	<ul>
                                	<li class="no-link"> Introduction to database</li>
									<li class="no-link">Introduction to DBMS</li>
									<li class="no-link">Creating the first database</li>
									<li class="no-link">DDL </li>
									<li class="no-link">Alter & Drop</li>
									<li class="no-link">Foreign Key & Truncate </li>
									<li class="no-link">DML </li>
									<li class="no-link">SQL Joins </li>
									<li class="no-link">Additional SQL features </li>
									<li class="no-link">Assignment  </li>
								</ul>
                            </div>
                        </div>
                    </div>
                    
					
					
					
					
                    
                </div>
                <div class="reviews">
                	<h4>Reviews</h4>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="rating-info">
                                <label>Detailed Rating</label>
                                <div class="rating-slide">
                                    <span>Stars 5</span>
                                    <div class="bar">
                                        <div class="fill" style="width:50%"></div>
                                    </div>
                                    <em>10</em>
                                </div>
                                <div class="rating-slide">
                                    <span>Stars 4</span>
                                    <div class="bar">
                                        <div class="fill" style="width:40%"></div>
                                    </div>
                                    <em>8</em>
                                </div>
                                <div class="rating-slide">
                                    <span>Stars 3</span>
                                    <div class="bar">
                                        <div class="fill" style="width:30%"></div>
                                    </div>
                                    <em>6</em>
                                </div>
                                <div class="rating-slide">
                                    <span>Stars 2</span>
                                    <div class="bar">
                                        <div class="fill" style="width:35%"></div>
                                    </div>
                                    <em>7</em>
                                </div>
                                <div class="rating-slide">
                                    <span>Stars 1</span>
                                    <div class="bar">
                                        <div class="fill" style="width:0"></div>
                                    </div>
                                    <em>0</em>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-5">
                        	<label>Average Rating</label>
                            <div class="rating-box">
                            	<div class="rating">4.3</div>
                                <div class="rating-star">
                                	<div class="fill" style="width:86%"></div>
                                </div>
                                <span>31 Ratings</span>
                            </div>
                        </div>
                    </div>
                    <div class="reviews-view">
                   
				   <?php 
							include 'reviews.php';
						?>
				   
				   </div>
            </div>
        </div>
        <!--footer-->
		<?php
			include 'footer.php';
		?>
		
		 <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>



