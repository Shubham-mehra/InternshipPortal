<?php
$name = $_POST["name"];
$email = $_POST["email"];
$subject = $_POST["subject"];
$message = $_POST["message"];

$con = mysqli_connect("localhost","root","","cmwdb");
$query = "insert into message(name, email, subject, message) values ('$name','$email', '$subject', '$message')";
mysqli_query($con, $query); 

if(mysqli_affected_rows($con)>0)
{
		
		echo "<script>alert('Message Sent!');
		window.location.href='contact-us.php';
		</script>";
}

else
{
	echo "<script>alert('Message Not Sent!');
	window.location.href='contact-us.php';
	</script>";
}


?>