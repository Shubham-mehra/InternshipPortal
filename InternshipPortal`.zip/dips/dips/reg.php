<?php
$name    =  $_POST["cname"];
$email              =  $_POST["email"];
$sec  =  $_POST["sec"];
$resec        =  $_POST["resec"];


$con = mysqli_connect("localhost","root","","cmwdb");
$query = "insert into registration(username, email, sec, resec) values ('$name','$email','$sec','$resec')";
mysqli_query($con, $query); 

if(mysqli_affected_rows($con)>0)
{
	echo "<script>alert('Successfully Done!');
		window.location.href='career.php';
		</script>";
}

else
{
	echo "<script>alert('Failure!');
		window.location.href='career.php';
		</script>";
}

?>