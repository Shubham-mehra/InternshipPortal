<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
	
    <title>Courses</title>
    
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/mylogo.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet"> 
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    
<body>
    <div class="wapper">
        
		<!-- header1-->
		<?php
			include 'header1.php';
		?>
		
		<!-- header2 -->
		<?php
			include 'header2.php';
		?>
		
        <section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/courses-banner.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>Courses </h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
        	<div class="container">
            	<ul>
                	<li><a href="index.php">Home</a></li>
                    <li><a href="courses-gride-sideBar.php">All courses</a></li>
                </ul>
            </div>
        </section>
        <section class="courses-view">
        	<div class="container">
            	<div class="row">
                	<div class="col-md-3">
                    	<div class="right-slide left">
                        	<h3>Catagories</h3>
                            <ul class="catagorie-list">
                            	<li><a href="course-details-html-css.php">HTML & CSS</a></li>
								<li><a href="course-details-js.php">JavaScript & AJAX</a></li>
                                <li><a href="course-details-bootstrap.php">Bootstrap</a></li>
                                <li><a href="course-details-sql.php">SQL</a></li>
                                <li><a href="course-details-php.php">PHP</a></li>
              
                            </ul>
                            
                      <!--      
                            <h3>Related Courses</h3>
                            <div class="recent-post">
                            	<div class="post-slide">
                                	<div class="img"><img src="images/blog/post-img1.jpg" alt=""></div>
                                    <p><a href="#">when an unknown printer took a galley of type and scrambled</a></p>
                                    <div class="date">$200</div>
                                </div>
                                <div class="post-slide">
                                	<div class="img"><img src="images/blog/post-img2.jpg" alt=""></div>
                                    <p><a href="#">when an unknown printer took a galley of type and scrambled</a></p>
                                    <div class="date">FREE</div>
                                </div>
                                <div class="post-slide">
                                	<div class="img"><img src="images/blog/post-img3.jpg" alt=""></div>
                                    <p><a href="#">when an unknown printer took a galley of type and scrambled</a></p>
                                    <div class="date">$78</div>
                                </div>
                            </div>
                            -->
							
							<!--
                            <h3>Keywords</h3>
                            <ul class="keyword-list">
                            	<li><a href="#">Html</a></li>
                                <li><a href="#">Boostrap</a></li>
                                <li><a href="#">Css3</a></li>
                                <li><a href="#">Jquery</a></li>
                                <li><a href="#">Student</a></li>
                                <li><a href="#">Html</a></li>
                                <li><a href="#">Boostrap</a></li>
                                <li><a href="#">Css3</a></li>
                                <li><a href="#">Jquery</a></li>
                                <li><a href="#">Student</a></li>
                            </ul>
							-->
                        </div>
                    </div>
                    <div class="col-md-9">
                    	<div class="filter-row">
                            <div class="view-type">
							<!--
                                <a href="courses-gride-sideBar.html" class="active"><i class="fa fa-th-large"></i></a>
                                <a href="courses-list-sideBar.html"><i class="fa fa-list"></i></a> -->
                            </div>  
                            <div class="search">
                                <input type="text" placeholder="Search">
                                <input type="submit" value="">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img4.jpg" alt="">
                                        <div class="price">$18</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">HTML & CSS </div>
                                        <div class="expert"><span>By </span> Michael Windzor</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details-html-css.php" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img5.jpg" alt="">
                                        <div class="price free">free</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">JavaScript & AJAX</div>
                                        <div class="expert"><span>By </span> Michael Windzor</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details-js.php" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img6.jpg" alt="">
                                        <div class="price">$23</div>
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">Bootstrap</div>
                                        <div class="expert"><span>By </span> text of the printing</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details-bootstrap.php" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img7.jpg" alt="">
                                        <div class="price">$78</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">SQL</div>
                                        <div class="expert"><span>By </span> unknown printer</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details-sql.php" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img6.jpg" alt="">
                                        <div class="price">$23</div>
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">PHP</div>
                                        <div class="expert"><span>By </span> text of the printing</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details-php.php" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<!--
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img4.jpg" alt="">
                                        <div class="price">$18</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">Basic Time Management Course</div>
                                        <div class="expert"><span>By </span> Michael Windzor</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details.html" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img5.jpg" alt="">
                                        <div class="price free">free</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">Introduction to Mobile Apps Development</div>
                                        <div class="expert"><span>By </span> Michael Windzor</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details-free.html" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img7.jpg" alt="">
                                        <div class="price">$78</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">Lorem Ipsum has been the</div>
                                        <div class="expert"><span>By </span> unknown printer</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details.html" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img6.jpg" alt="">
                                        <div class="price">$23</div>
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">Lorem Ipsum is simply dummy</div>
                                        <div class="expert"><span>By </span> text of the printing</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details.html" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img4.jpg" alt="">
                                        <div class="price">$18</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">Basic Time Management Course</div>
                                        <div class="expert"><span>By </span> Michael Windzor</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details.html" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="course-post">
                                    <div class="img">
                                        <img src="images/courses/courses-img5.jpg" alt="">
                                        <div class="price free">free</div>    
                                        <div class="icon">
                                            <a href="#"><img src="images/book-icon.png" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="info">
                                        <div class="name">Introduction to Mobile Apps Development</div>
                                        <div class="expert"><span>By </span> Michael Windzor</div>
                                    </div>
                                    <div class="product-footer">
                                        <div class="comment-box">	
                                            <div class="box"><i class="fa fa-users"></i>35 Enrolled</div>
                                        </div>
                                        <div class="rating">
                                            <div class="fill" style="width:45%"></div>
                                        </div>
                                        <div class="view-btn">
                                            <a href="course-details-free.html" class="btn">view more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						-->
						<!--
                        <div class="pagination">
                            <ul>
                                <li class="next"><a href="#"><i class="fa fa-angle-left"></i><span>Next</span></a></li>
                                <li class="active"><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li class="prev"><a href="#"><span>prev</span> <i class="fa fa-angle-right"></i></a></li>
                            </ul>
                        </div>
						-->
                    </div>
                </div>
            	
            </div>
        </section>
        
		<!--footer-->
		<?php
			include 'footer.php';
		?>
		
	</div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>
