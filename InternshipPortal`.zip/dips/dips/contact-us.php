<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
    <title>Contact-us</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/mylogo.ico">
    
    <!-- CSS Stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <link href="../../../../fonts.googleapis.com/css66a5.css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
    
<body>
    
	<!-- header1 -->
	<?php
		include 'header1.php';
	?>
	
	<!-- header2 -->
	
	<?php
		include 'header2.php';
	?>
	
	    <section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/contact-us.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>Contact Us</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
        	<div class="container">
            	<ul>
                	<li><a href="index-2.php">Home</a></li>
                    <li><a href="contact-us.php">Contact Us</a></li>
                </ul>
            </div>
        </section>
        <section class="contact-detail">
        	<div class="container">
                <div class="section-title">
                    
                    <h2>Get in Touch</h2>
                  
                </div>
                <div class="contact-boxView">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="contact-box yello">
                                <div class="icon-box">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <h3>location</h3>
								<br>
								<div class="row">
									<div class="col-sm-4">
								<h4>USA Branch</h4>
                                <p>Fendikli Inc
Registerd in the State of New York
65-41 Saunders Street, Suite 4D, Rego Park, New York
Woodbridge, New Jersey USA 00725
Contact:
M:+1-347-459-6530 +1-646-522-8355
Email: infousa@azansys.com</p>
								</div>
								
									<div class="col-sm-4">
										<h4>India Branch</h4>
										<p>
                                        Azansys Info Tech Pvt. Ltd.
Plot no. 16/17 Avas Vikas, Behind HDFC
Bank/LIC Rudrapur, U.S. Nagar
Uttarakhand, India 263152
Contact:
Phone:+91-5944-244975
Fax:+91-5944-244975
M:+91-9997789084, 9917734079, 9675078592
Email: inf@azansys.com
                                        </p>
								</div>
								
								<div class="col-sm-4">
									<h4>Russia Branch</h4>
									<p>
                                    107023 Moscow, st. Malaya Semenovskaya,
9/3 125476 Moscow, st. Vasiliya Petushkova 8
Contact: +7-985-8850809
Contact: Person: Batalov Maxim
Email: maxim.batalov@azansys.com 
                                    </p>
							</div>

								
								</div>
                            </div>
                        </div>
						
						<div class="col-sm-4" style = "margin-top:50px">
                            <div class="contact-box green">
                                <div class="icon-box">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <h4>phone number</h4>
                                <p>+91-5944-244975</p>
                                <p>+91-9997789084</p>
								 <p>+91-5944-244975</p>
                            </div>
                        </div>
                        <div class="col-sm-4" style = "margin-top:50px">
                            <div class="contact-box red">
                                <div class="icon-box">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <h4>email address</h4>
                                <p><a href="mailTo:info@azansys.com">info@azansys.com</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="contact-message">
        	<div class="container">
            	<div class="section-title">
                	<h2>SEND A MESSAGE</h2>
                </div>
                <div class="form-filde">
                    <form action="msg.php" method="post">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="input-box">
                                    <input type="text" placeholder="Name" data-validation="required" name="name" id = "name" required = "" >
                                </div>
                                <div class="input-box">
                                    <input type="text" placeholder="Email" data-validation="required" name="email" id = "email" required = "" >
                                </div>
                                <div class="input-box">
                                    <input type="text" placeholder="Subject" data-validation="required" name="subject"  id = "sub" required = "" >
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-box">
                                    <textarea placeholder="Message" data-validation="required" name="message"></textarea>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="submit-box">
                                    <input type="submit" value="SEND" class="btn">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
        <section class="contact-map" id="map">
        </section>
        
		<!--footer-->
		<?php
			include 'footer.php';
		?>
    
	</div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.form-validator.min.js"></script>
    <script type='text/javascript' src='../../../../maps.google.com/maps/api/jsff9b?key=AIzaSyAciPo9R0k3pzmKu6DKhGk6kipPnsTk5NU'></script>
    <script type="text/javascript" src="js/map-styleMain.js"></script>
    <script type="text/javascript" src="js/placeholder.js"></script>
    <script type="text/javascript" src="js/coustem.js"></script>
</body>
